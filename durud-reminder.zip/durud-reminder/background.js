const audioFiles = [
  "durud1.mp3", "durud2.mp3", "durud3.mp3",
  "durud4.mp3", "durud5.mp3", "durud6.mp3",
  "durud7.mp3", "durud8.mp3", "durud9.mp3"
];

// 1. Alarm Listener
chrome.alarms.onAlarm.addListener((alarm) => {
  console.log("[BACKGROUND] Alarm Fired:", alarm.name, "Time:", new Date().toLocaleTimeString());
  
  if (alarm.name === "durudAlarm") {
    playDurud();
    updateNextReminderTime(); // This function updates the time
  }
});

// 2. Message Listener
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === "settingsUpdated") {
    setupAlarm();
  }
});

// 3. Setup Alarm
function setupAlarm() {
  chrome.storage.sync.get(["interval", "enabled"], (data) => {
    chrome.alarms.clear("durudAlarm");

    if (data.enabled) {
      const intervalMinutes = parseFloat(data.interval) || 5;

      chrome.alarms.create("durudAlarm", {
        delayInMinutes: intervalMinutes,
        periodInMinutes: intervalMinutes
      });

      console.log(`[BACKGROUND] Loop Alarm set for every ${intervalMinutes} minutes.`);
    } else {
      console.log("[BACKGROUND] Alarm disabled.");
    }
  });
}

// 4. Play Audio Logic
async function playDurud() {
  await createOffscreen();
  await new Promise(resolve => setTimeout(resolve, 500));

  chrome.storage.sync.get(["durud"], (data) => {
    let fileToPlay = data.durud || "random";

    if (fileToPlay === "random") {
      const randomIndex = Math.floor(Math.random() * audioFiles.length);
      fileToPlay = audioFiles[randomIndex];
    }

    console.log("[BACKGROUND] Playing Audio:", fileToPlay);

    chrome.runtime.sendMessage({
      action: "playOffscreenAudio",
      file: fileToPlay
    }, () => {
      if (chrome.runtime.lastError) {
        console.error("[BACKGROUND] Error sending message:", chrome.runtime.lastError.message);
      }
    });
  });
}

// 5. [NEW] Update Next Reminder Time in Storage
function updateNextReminderTime() {
  chrome.storage.sync.get(["interval"], (data) => {
    const min = parseFloat(data.interval) || 5;
    
    // Calculate current time + interval
    const now = new Date();
    now.setMinutes(now.getMinutes() + min);
    
    const nextTimeStr = now.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });

    // Save the new time to storage so popup can show it
    chrome.storage.sync.set({ nextReminder: nextTimeStr }, () => {
      console.log("[BACKGROUND] Next reminder updated to:", nextTimeStr);
    });
  });
}

// 6. Create Offscreen Document
async function createOffscreen() {
  if (await chrome.offscreen.hasDocument()) {
    return;
  }
  
  await chrome.offscreen.createDocument({
    url: "offscreen.html",
    reasons: ["AUDIO_PLAYBACK"],
    justification: "Play Durud reminder audio",
  });
}
const $ = id => document.getElementById(id);

const intervalSelect = $('intervalSelect');
const durudSelect = $('durudSelect');
const toggleReminder = $('toggleReminder');
const nextReminderText = $('nextReminderText');
const playBtn = $('playBtn');
const shareBtn = $('shareBtn');
const saveIcon = $('saveIcon');
const saveText = $('saveText');
const copyFeedback = $('copyFeedback');

let audioPlayer = null;

// --- 1. PLAY BUTTON LOGIC (Preview only) ---
playBtn.addEventListener("click", () => {
  let file = durudSelect.value;
  
  if (file === "random") {
    const audioFiles = [
      "durud1.mp3", "durud2.mp3", "durud3.mp3",
      "durud4.mp3", "durud5.mp3", "durud6.mp3",
      "durud7.mp3", "durud8.mp3", "durud9.mp3"
    ];
    file = audioFiles[Math.floor(Math.random() * audioFiles.length)];
  }

  const url = chrome.runtime.getURL(`assets/audios/${file}`);

  if (audioPlayer) audioPlayer.pause();
  audioPlayer = new Audio(url);
  audioPlayer.play();
});

// --- 2. SHARE LOGIC ---
shareBtn.addEventListener("click", () => {
  navigator.clipboard.writeText("https://chromewebstore.google.com/detail/durud-reminder")
    .then(() => {
      copyFeedback.style.display = "block";
      setTimeout(() => (copyFeedback.style.display = "none"), 1500);
    });
});

// --- 3. AUTO-SAVE LOGIC ---
function saveSettings() {
  // Show saving animation
  saveIcon.classList.add('saving-icon');
  saveText.textContent = "Saving...";

  const settings = {
    interval: parseInt(intervalSelect.value),
    durud: durudSelect.value,
    enabled: toggleReminder.checked,
    nextReminder: toggleReminder.checked
      ? computeNextTime(intervalSelect.value)
      : "—"
  };

  chrome.storage.sync.set(settings, () => {
    nextReminderText.textContent = settings.nextReminder;
    
    // Notify background script to update the alarm
    chrome.runtime.sendMessage({ action: "settingsUpdated" });
    
    // Stop animation
    setTimeout(() => {
      saveIcon.classList.remove('saving-icon');
      saveText.textContent = "Auto-Save";
    }, 600);
  });
}

// Event Listeners for Auto-Save
intervalSelect.addEventListener('change', saveSettings);
durudSelect.addEventListener('change', saveSettings);
toggleReminder.addEventListener('change', saveSettings);

// Helper for Time Calculation
function computeNextTime(min) {
  const t = new Date();
  t.setMinutes(t.getMinutes() + Number(min));
  return t.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });
}

// --- 4. LOAD SETTINGS ---
chrome.storage.sync.get(
  ["interval", "durud", "enabled", "nextReminder"],
  (data) => {
    intervalSelect.value = data.interval || "5";
    durudSelect.value = data.durud || "random";
    toggleReminder.checked = data.enabled || false;
    nextReminderText.textContent = data.nextReminder || "—";
  }
);
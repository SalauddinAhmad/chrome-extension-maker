const $ = id => document.getElementById(id);

const intervalSelect = $('intervalSelect');
const durudSelect = $('durudSelect');
const toggleReminder = $('toggleReminder');
const nextReminderText = $('nextReminderText');
const saveBtn = $('saveBtn');
const devBtn = $('devBtn');
const devInfo = $('devInfo');
const devName = $('devName');
const playBtn = $('playBtn');
const shareBox = $('shareBox');
const copyStatus = $('copyStatus');

devBtn.addEventListener("click", () => {
  devInfo.style.display =
    devInfo.style.display === "block" ? "none" : "block";
});

devName.addEventListener("click", () => {
  window.open("https://www.facebook.com/salauddinahmad101", "_blank");
});

let audioPlayer = null;

playBtn.addEventListener("click", () => {
  let file = durudSelect.value;
  
  if (file === "random") {
    const audioFiles = [
      "durud1.mp3", "durud2.mp3", "durud3.mp3",
      "durud4.mp3", "durud5.mp3", "durud6.mp3",
      "durud7.mp3", "durud8.mp3", "durud9.mp3"
    ];
    file = audioFiles[Math.floor(Math.random() * audioFiles.length)];
  }

  const url = chrome.runtime.getURL(`assets/audios/${file}`);

  if (audioPlayer) audioPlayer.pause();

  audioPlayer = new Audio(url);
  audioPlayer.play();
});

shareBox.addEventListener("click", () => {
  navigator.clipboard.writeText("https://chromewebstore.google.com/detail/durud-reminder")
    .then(() => {
      copyStatus.textContent = "Link copied!";
      setTimeout(() => (copyStatus.textContent = ""), 1400);
    });
});

saveBtn.addEventListener("click", () => {
  const settings = {
    interval: parseInt(intervalSelect.value),
    durud: durudSelect.value, // This now holds the filename or 'random'
    enabled: toggleReminder.checked,
    nextReminder: toggleReminder.checked
      ? computeNextTime(intervalSelect.value)
      : "—"
  };

  chrome.storage.sync.set(settings, () => {
    nextReminderText.textContent = settings.nextReminder;
    chrome.runtime.sendMessage({ action: "settingsUpdated" });
    saveBtn.textContent = "Saved ✔";
    setTimeout(() => (saveBtn.textContent = "Save Reminder"), 900);
  });
});

function computeNextTime(min) {
  const t = new Date();
  t.setMinutes(t.getMinutes() + Number(min));
  return t.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });
}

chrome.storage.sync.get(
  ["interval", "durud", "enabled", "nextReminder"],
  (data) => {
    intervalSelect.value = data.interval || "5";
    durudSelect.value = data.durud || "random";
    toggleReminder.checked = data.enabled || false;
    nextReminderText.textContent = data.nextReminder || "—";
  }
);
// Offscreen document script — plays audio on demand.

console.log('[OFFSCREEN] offscreen.js loaded');

const AUDIO_DIR = 'assets/audios/';

// Helper to get extension URL
function audioURL(filename) {
  return chrome.runtime.getURL(`${AUDIO_DIR}${filename}`);
}

// Play file once with error handling
async function playOnce(filename) {
  if (!filename) {
    console.error('[OFFSCREEN] playOnce: missing filename');
    return false;
  }
  console.log('[OFFSCREEN] playOnce requested:', filename);

  try {
    const src = audioURL(filename);
    const audio = new Audio(src);
    audio.preload = 'auto';
    audio.volume = 1.0;

    audio.onerror = (ev) => {
      console.error('[OFFSCREEN] audio element error for', filename, ev);
    };

    // Attempt to play
    const p = audio.play();
    if (p && typeof p.then === 'function') {
      await p;
    }
    console.log('[OFFSCREEN] PLAY started:', filename);

    // Cleanup on end
    audio.addEventListener('ended', () => {
      try { 
        audio.pause(); 
        audio.currentTime = 0; 
      } catch (e) {}
      console.log('[OFFSCREEN] PLAY ended:', filename);
    }, { once: true });

    return true;
  } catch (err) {
    console.error('[OFFSCREEN] playOnce failed:', err);
    return false;
  }
}

// Message listener from background service worker
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  console.log('[OFFSCREEN] Received message:', message);

  (async () => {
    try {
      if (!message || !message.action) {
        sendResponse({ ok: false, error: 'invalid_message' });
        return;
      }

      // Action: Play Audio
      if (message.action === 'playOffscreenAudio') {
        const file = message.file;
        if (!file) {
          sendResponse({ ok: false, error: 'no_file' });
          return;
        }
        const ok = await playOnce(file);
        sendResponse({ ok: !!ok });
        return;
      }

      // Unknown action
      sendResponse({ ok: false, error: 'unknown_action' });
    } catch (err) {
      console.error('[OFFSCREEN] onMessage error', err);
      sendResponse({ ok: false, error: String(err) });
    }
  })();

  return true; // Keep channel open for async response
});